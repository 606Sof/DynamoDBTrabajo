
package prueba.aws.PruebaAws2;

import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

/**
 * The module containing all dependencies required by the {@link Handler}.
 */
public class DependencyFactory {
	
	
	
	private final static String  AWS_ACCESS_KEY_ID = "ASIARPIZAHTFN3HN2ZYZ";
	private final static String  AWS_SECRET_ACCESS_KEY = "hSNHZCQ3M5hOZQSvYbP7rOX+5s0PmNDFIcwmzoVy";
	private final static String AWS_SESSION_TOKEN = "IQoJb3JpZ2luX2VjECIaCXVzLXdlc3QtMiJHMEUCIQDEvVyWPRALqpT9QQHNyWZ4cFQUKMp0P25mBZ4p3CRgcwIgLCjnkc+kSF08Rcc/zr3xCCJCdAOPnxhdne1N54TriYAqqwIISxAAGgwxMDE1MjEwNDY3MzAiDC0h/oNAb97Au5rXLiqIAuBx0eA5Eq5kHY+/UZ5XHRWlPb8wT+Q39xkqD95939eGJUoCzt/tYIOB3g4vb+wyl0/xRYixDX1m1BG/4w1Eh5vatGOMphxHmKWKJG1/OCnX2/Tm+kKjHKCxiKO5L3VY3E6IOTbkPc9FIwKuoiCsjJYftmDnQuJ8gJYjFSGnza6fw5DZr6hQtTpIPfGTEhraiHPHK2IjfckOa1gl8+iwFWOTmyZiPrWvQ52M8U/QCHLjh7tt3icQ3ZrAGNjaypPR6xlHAFS4UTrMUhLaJwXSzwsRVRUoVvrbwR5cCV5MJZOhJET5l0jkQjV4B7xxoYbCUwxhNy8GbAEUmpVgXHnln0/FcBw0dQ5SZDCtocO9BjqdASwi0Z9bz3T4nStOLIh13HrZShMJUrAJATUGnqQeAX44JelQZB/Gru5KmgpLYJq73CJWSI0EcExMA6530LJJ2Bp0eNyDDZc+SPvwsete2SKtN75kU5Qwt3Bq7Q5JzsfEJVMbG/QLllX/a5v6V7L6govNZQqRzPMXyN8tk3QJudGtZjG6NaGkOBgYtjBQoWQVx5mP7QZLX2Jph/cMTTs=";
	
    private DependencyFactory() {}

    /**
     * @return an instance of DynamoDbClient
     */
    public static DynamoDbClient dynamoDbClient() {
    	AwsSessionCredentials credSesion = AwsSessionCredentials.create(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN);
    
    	
        return DynamoDbClient.builder()
        		.region(Region.US_EAST_1)
        		.credentialsProvider(StaticCredentialsProvider.create(credSesion))
                       .build();
    }
}
