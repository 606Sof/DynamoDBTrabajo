package prueba.aws.PruebaAws2;

import org.junit.jupiter.api.Test;

public class HandlerTest {
    //TODO add tests here
}
