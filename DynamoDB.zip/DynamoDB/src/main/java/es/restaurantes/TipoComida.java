package es.restaurantes;


public enum TipoComida {
	PlatoPrincipal, SegundoPlato, Postre, Aperitivo;
}
