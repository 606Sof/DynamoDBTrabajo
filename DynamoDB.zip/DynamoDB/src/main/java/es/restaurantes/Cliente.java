package es.restaurantes;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@DynamoDbBean
public class Cliente {
	
	private String nombre;
	private String apellidos;
	private Reserva reserva;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public Reserva getReserva() {
		return reserva;
	}
	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}
	@Override
	public String toString() {
		return "[nombre=" + nombre + ", apellidos=" + apellidos + ", reserva=" + reserva + "]";
	}
		
}
