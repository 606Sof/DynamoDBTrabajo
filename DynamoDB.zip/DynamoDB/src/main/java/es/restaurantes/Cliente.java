package es.restaurantes;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@DynamoDbBean
public class Cliente {
	
	private String nombre;
	private String apellidos;
	
	public Cliente(String nombreCli, String apellidosCli) {
		this.nombre = nombreCli;
		this.apellidos = apellidosCli;
	}
	public Cliente() {
		// TODO Auto-generated constructor stub
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
}
