package es.restaurantes;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@DynamoDbBean
public class Comida {
	
	private String nombre;
	private TipoComida tipo;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public TipoComida getTipo() {
		return tipo;
	}
	public void setTipo(TipoComida tipo) {
		this.tipo = tipo;
	}
	@Override
	public String toString() {
		return "Comida [nombre=" + nombre + ", tipo=" + tipo + "]";
	}	
	
}
